<?php
/**
 * Nothing to do here
 *
 * @link       https://themeisle.com/plugins/feedzy-rss-feed/
 * @since      3.0.0
 *
 * @package    feedzy-rss-feeds
 */
